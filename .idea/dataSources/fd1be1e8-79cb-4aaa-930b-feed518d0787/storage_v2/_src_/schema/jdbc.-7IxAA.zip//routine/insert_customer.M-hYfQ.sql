create
    definer = root@localhost procedure insert_customer(IN name_in varchar(255), IN address_in varchar(255),
                                                       IN email_in varchar(255))
begin
    insert into customer(address, email, name)  value (address_in,email_in,name_in);
end;

